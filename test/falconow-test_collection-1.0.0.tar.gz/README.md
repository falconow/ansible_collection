# Ansible Collection - falconow.test_collection

Тестовая коллекция, которая содержит модуль по созданию файла
и роль которая его запускает.

